create
    definer = root@localhost procedure insertCustomer(IN namee varchar(20), IN addresss varchar(50))
BEGIN
    INSERT INTO customer(name, address) VALUES (namee,addresss);
end;

