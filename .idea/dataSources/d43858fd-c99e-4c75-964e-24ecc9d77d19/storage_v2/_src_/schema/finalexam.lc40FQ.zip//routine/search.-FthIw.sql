create
    definer = root@localhost procedure search(IN _str varchar(30))
begin
    select * from product where name LIKE CONCAT('%', _str , '%');
end;

