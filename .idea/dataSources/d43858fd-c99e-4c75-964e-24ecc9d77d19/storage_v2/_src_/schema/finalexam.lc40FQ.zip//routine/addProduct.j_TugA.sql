create
    definer = root@localhost procedure addProduct(IN _name varchar(30), IN _price int, IN _quatity int,
                                                  IN _color varchar(20), IN _descrip varchar(500),
                                                  IN _category varchar(20))
begin
    insert into product(name, price, color,quantity, description, category) values (_name,_price,_color,_quatity,_descrip,_category);

end;

